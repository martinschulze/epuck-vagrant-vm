/*!
 * \file	main.c
 * \date	2014-06-25
 *
 * \author	Darius Kellermann <darius.kellermann@smail.fh-koeln.de>
 */

#include <p30F6014A.h>

#define LED0		_LATA6
#define LED1		_LATA7
#define LED2		_LATA9
#define LED3		_LATA12
#define LED4		_LATA10
#define LED5		_LATA13
#define LED6		_LATA14
#define LED7		_LATA15

#define LED0_DIR	_TRISA6
#define LED1_DIR	_TRISA7
#define LED2_DIR	_TRISA9
#define LED3_DIR	_TRISA12
#define LED4_DIR	_TRISA10
#define LED5_DIR	_TRISA13
#define LED6_DIR	_TRISA14
#define LED7_DIR	_TRISA15

#define OUTPUT_PIN	0

void myWait(long milli)
{
	long i;
	for(i=0;i<(milli*1500);i++);
}

int main(void)
{
	LED0 = 0;
	LED1 = 0;
	LED2 = 0;
	LED3 = 0;
	LED4 = 0;
	LED5 = 0;
	LED6 = 0;
	LED7 = 0;
	LED0_DIR = OUTPUT_PIN;
	LED1_DIR = OUTPUT_PIN;
	LED2_DIR = OUTPUT_PIN;
	LED3_DIR = OUTPUT_PIN;
	LED4_DIR = OUTPUT_PIN;
	LED5_DIR = OUTPUT_PIN;
	LED6_DIR = OUTPUT_PIN;
	LED7_DIR = OUTPUT_PIN;

	while (1) {
		myWait(500);
		LED0 ^= 1;
		LED1 ^= 1;
		LED2 ^= 1;
		LED3 ^= 1;
		LED4 ^= 1;
		LED5 ^= 1;
		LED6 ^= 1;
		LED7 ^= 1;
	}
}
